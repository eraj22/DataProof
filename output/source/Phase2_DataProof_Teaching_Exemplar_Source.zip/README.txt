TEACHING EXEMPLAR SOURCE - NOT FOR SUBMISSION

This ZIP contains the ReportLab builder that reproducibly generates the supplied
PDF exemplar, plus an AI-generated LaTeX teaching skeleton and bibliography.
A TeX compiler was not available in the environment, so main.tex is a portable
outline rather than the exact typesetting source of the PDF. The student must
independently write the paper, verify all citations, insert the assigned project
code, compile the final 8-10 page paper, and obtain official Turnitin reports
from the institution.
